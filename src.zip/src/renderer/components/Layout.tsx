import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { useStore } from '../src/store';
import { Link } from 'react-router-dom';

const api = (channel: string, ...args: any[]) => window.api!.invoke(channel, ...args);

const toggleTheme = async () => {
  const isDark = document.documentElement.classList.toggle('dark');
  await api('store:set', 'ui.theme', isDark ? 'dark' : 'light');
};

export function Layout() {
  const { collapsed, brand, actions } = useStore(state => ({ 
    collapsed: state.collapsed, 
    brand: state.brand, 
    actions: state.actions 
  }));
  const location = useLocation();

  return (
    <div className="h-screen w-screen overflow-hidden grid" style={{ gridTemplateColumns: collapsed ? '76px 1fr' : '260px 1fr' }}>
      {/* Sidebar */}
      <aside className="h-full card p-3 flex flex-col">
        <div className="flex items-center justify-between gap-2 px-2">
          <div className="font-bold tracking-wide text-sm">{collapsed ? 'ðŸ£' : `ðŸ£ ${brand}`}</div>
          <div className="flex items-center gap-1">
            <button className="btn btn-ghost" title="Toggle theme" onClick={toggleTheme}>ðŸŒ“</button>
            <button className="btn btn-ghost" title="Collapse" onClick={actions.toggleCollapsed}>{collapsed ? 'âž¡ï¸Ž' : 'â¬…ï¸Ž'}</button>
          </div>
        </div>

        <nav className="mt-2 space-y-1">
          <SectionLabel hidden={collapsed}>Orders</SectionLabel>
          <NavLink to="/" text="Order Process" icon="ðŸ“’" collapsed={collapsed} active={location.pathname === '/'} />
          <SectionLabel hidden={collapsed}>Catalog</SectionLabel>
          <NavLink to="/categories" text="Categories" icon="ðŸ—‚ï¸Ž" collapsed={collapsed} active={location.pathname === '/categories'} />
          <NavLink to="/items" text="Items" icon="ðŸ🍱" collapsed={collapsed} active={location.pathname === '/items'} />
          <NavLink to="/addons" text="Addons" icon="âž•" collapsed={collapsed} active={location.pathname === '/addons'} />
          <SectionLabel hidden={collapsed}>System</SectionLabel>
          <NavLink to="/settings" text="Settings" icon="âš™ï¸Ž" collapsed={collapsed} active={location.pathname === '/settings'} />
        </nav>

        <div className="mt-auto">
          <button className="btn w-full btn-ghost">ðŸšª {collapsed ? '' : 'Logout'}</button>
        </div>
      </aside>

      {/* Main center */}
      <main className="h-full overflow-hidden p-4">
        <Outlet />
      </main>
    </div>
  );
}

function NavLink({ to, text, icon, collapsed, active = false }: { to: string; text: string; icon?: string; collapsed?: boolean; active?: boolean }) {
  return (
    <Link to={to} className={`flex items-center gap-2 px-3 py-2 rounded-xl ${active ? 'bg-slate-800/70' : 'hover:bg-slate-800/50'}`}>
      <span>{icon || 'â€¢'}</span>
      {!collapsed && <span className="text-sm muted">{text}</span>}
    </Link>
  );
}

function SectionLabel({ children, hidden }: any) {
  if (hidden) return <div className="mt-2" />;
  return <div className="mt-2 mb-1 uppercase tracking-wide text-xs muted px-2">{children}</div>;
}
