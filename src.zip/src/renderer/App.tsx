import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { OrderProcessPage } from './pages/OrderProcessPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { ItemsPage } from './pages/ItemsPage';
import { AddonsPage } from './pages/AddonsPage';
import { SettingsPage } from './pages/SettingsPage';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<OrderProcessPage />} />
        <Route path="categories" element={<CategoriesPage />} />
        <Route path="items" element={<ItemsPage />} />
        <Route path="addons" element={<AddonsPage />} />
        <Route path="settings" element={<SettingsPage />} />
      </Route>
    </Routes>
  );
}
