import { useMemo, useState, useEffect } from 'react';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getFilteredRowModel,
  getSortedRowModel,
} from '@tanstack/react-table';

type Promo = {
  code: string;
  type: string;
  value: number;
  min_total: number;
  max_discount: number;
  start_at: string;
  end_at: string;
  active: boolean;
};

const columnHelper = createColumnHelper<Promo>();

const columns = [
  columnHelper.accessor('code', { header: 'Code' }),
  columnHelper.accessor('type', { header: 'Type' }),
  columnHelper.accessor('value', { header: 'Value' }),
  columnHelper.accessor('min_total', { header: 'Min Total' }),
  columnHelper.accessor('max_discount', { header: 'Max Discount' }),
  columnHelper.accessor('start_at', { header: 'Starts' }),
  columnHelper.accessor('end_at', { header: 'Ends' }),
  columnHelper.accessor('active', { header: 'Active', cell: info => (info.getValue() ? '✅' : '—') }),
];

function GlobalFilter({ filter, setFilter }) {
  return (
    <input
      value={filter || ''}
      onChange={e => setFilter(e.target.value)}
      placeholder={`Search...`}
      className="p-2 border rounded"
    />
  );
}

function PromosPage() {
  const [data, setData] = useState<Promo[]>([]);
  const [globalFilter, setGlobalFilter] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      const promos = await window.api.invoke('catalog:listPromos');
      setData(promos);
    };
    fetchData();
  }, []);

  const table = useReactTable({
    data,
    columns,
    state: {
      globalFilter,
    },
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Promos</h1>
        <GlobalFilter
          filter={globalFilter}
          setFilter={setGlobalFilter}
        />
      </div>
      <table className="w-full">
        <thead>
          {table.getHeaderGroups().map(headerGroup => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map(header => (
                <th key={header.id} onClick={header.column.getToggleSortingHandler()} className="p-2 text-left bg-gray-200 cursor-pointer">
                  {flexRender(header.column.columnDef.header, header.getContext())}
                  {{
                    asc: ' 🔼',
                    desc: ' 🔽',
                  }[header.column.getIsSorted() as string] ?? null}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map(row => (
            <tr key={row.id}>
              {row.getVisibleCells().map(cell => (
                <td key={cell.id} className="p-2 border-t">
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default PromosPage;