import React from 'react';

export function SettingsPage() {
  return <div>Settings Page</div>;
}
