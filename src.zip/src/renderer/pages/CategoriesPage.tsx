import React, { useEffect } from 'react';
import { useStore } from '../src/store';
import {Table, TableHeader, TableColumn, TableBody, TableRow, TableCell} from "@heroui/react";

export function CategoriesPage() {
  const { cats, actions } = useStore();

  useEffect(() => {
    actions.fetchInitialData();
  }, []);

  return (
    <div className="card" style={{ margin: '24px', padding: '24px' }}>
      <div className="toolbar">
        <h3>Categories</h3>
        <span className="muted">Read-only</span>
      </div>
      <Table aria-label="Categories">
        <TableHeader>
          <TableColumn>#</TableColumn>
          <TableColumn>Name (EN)</TableColumn>
          <TableColumn>Name (AR)</TableColumn>
          <TableColumn>Visible</TableColumn>
        </TableHeader>
        <TableBody items={cats}>
          {(item) => (
            <TableRow key={item.id}>
              <TableCell>{item.position}</TableCell>
              <TableCell>{item.name}</TableCell>
              <TableCell>{item.name_ar}</TableCell>
              <TableCell>{item.visible ? 'âœ…' : 'â€”'}</TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}