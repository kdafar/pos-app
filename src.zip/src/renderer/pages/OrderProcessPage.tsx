import React, { useEffect, useMemo } from 'react';
import { useStore } from '../src/store';
import {Table, TableHeader, TableColumn, TableBody, TableRow, TableCell} from "@heroui/react";

export function OrderProcessPage() {
  const {
    items, q, catId, subId, cats, subs, tabs, currentId, order, lines, prepared, actions
  } = useStore();

  useEffect(() => {
    actions.fetchInitialData();
  }, []);

  const subOptions = useMemo(
    () => subs.filter(s => !catId || s.category_id === catId),
    [subs, catId]
  );

  return (
    <div className="h-full grid grid-cols-2 gap-4">
      {/* Left side */}
      <div>
        {/* Top: tabs + order type */}
        <div className="flex items-center justify-between gap-3">
          <Tabs
            tabs={tabs}
            currentId={currentId}
            onSelect={async (id) => { actions.setCurrentId(id); await actions.refreshCurrent(); }}
            onNew={() => actions.newOrder(2)}
          />
          <OrderTypePicker
            value={order?.order_type || 2}
            onChange={(t) => actions.setOrderType(t)}
          />
        </div>

        {/* Filters */}
        <div className="mt-3 flex items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="muted text-xs">Categories:</span>
            <button
              className={`chip ${!catId ? 'bg-slate-800/60' : ''}`}
              onClick={() => { actions.setCatId(null); actions.setSubId(null); actions.refreshItems(); }}
            >All</button>
            {cats.map(c => (
              <button
                key={c.id}
                className={`chip ${catId === c.id ? 'bg-slate-800/60' : ''}`}
                onClick={() => { actions.setCatId(c.id); actions.setSubId(null); actions.refreshItems(); }}
              >{c.name}</button>
            ))}
          </div>

          <div className="flex gap-2 items-center">
            <input
              className="px-3 py-2 rounded-xl bg-slate-900/40 border border-slate-700/60 outline-none w-64"
              placeholder="Search name / Arabic / barcode"
              value={q}
              onChange={e => actions.setQ(e.target.value)}
              onKeyDown={(e) => (e.key === 'Enter') && actions.refreshItems()}
            />
            <button className="btn" onClick={actions.refreshItems}>Search</button>
          </div>
        </div>

        {/* Subcategories */}
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <span className="muted text-xs">Subcategories:</span>
          <button
            className={`chip ${!subId ? 'bg-slate-800/60' : ''}`}
            onClick={() => { actions.setSubId(null); actions.refreshItems(); }}
          >All</button>
          {subOptions.map(s => (
            <button
              key={s.id}
              className={`chip ${subId === s.id ? 'bg-slate-800/60' : ''}`}
              onClick={() => { actions.setSubId(s.id); actions.refreshItems(); }}
            >{s.name}</button>
          ))}
        </div>

        {/* Items grid */}
        <div className="mt-4 grid gap-3"
             style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))', height: 'calc(100% - 168px)', overflow: 'auto' }}>
          {items.map(it => (
            <div key={it.id} className="card p-3 flex flex-col gap-2">
              <div className="font-semibold">{it.name}</div>
              <div className="text-xs muted">{it.name_ar}</div>
              <div className="flex items-center justify-between text-sm">
                <span className="chip">{it.barcode || 'â€”'}</span>
                <strong className="tracking-wide">{it.price.toFixed(3)}</strong>
              </div>
              <button
                className="btn btn-primary mt-1"
                disabled={!!it.is_outofstock}
                onClick={() => actions.addItem(it, 1)}
              >
                {it.is_outofstock ? 'Out of stock' : 'Add to Cart'}
              </button>
            </div>
          ))}
          {items.length === 0 && (
            <div className="muted p-4">No items match your filters.</div>
          )}
        </div>
      </div>

      {/* Right: Cart & Prepared */}
      <aside className="h-full card p-4 flex flex-col overflow-hidden">
        {/* Current Order Summary */}
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm muted">Current Order</div>
            <div className="font-semibold">{order?.number || 'â€”'}</div>
          </div>
          <span className="chip">{labelForType(order?.order_type || 2)}</span>
        </div>

        {/* Cart lines */}
        <div className="mt-3 border-t border-slate-700/60 pt-2 overflow-auto" style={{ maxHeight: '40%' }}>
        <Table aria-label="Cart Lines">
          <TableHeader>
            <TableColumn>Item</TableColumn>
            <TableColumn>Qty</TableColumn>
            <TableColumn>Total</TableColumn>
            <TableColumn>Actions</TableColumn>
          </TableHeader>
          <TableBody items={lines}>
            {(item) => (
              <TableRow key={item.id}>
                <TableCell>{item.name}</TableCell>
                <TableCell>{item.qty}</TableCell>
                <TableCell>{item.line_total.toFixed(3)}</TableCell>
                <TableCell>
                  <button className="btn btn-ghost px-2" onClick={() => actions.decreaseLine(item)}>−</button>
                  <button className="btn btn-ghost px-2" onClick={() => actions.addItem({ id: item.item_id, name: item.name, price: item.unit_price } as any, 1)}>＋</button>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
          {(!lines || lines.length === 0) && (
            <div className="muted text-sm p-4">Cart is empty. Add items from the middle panel.</div>
          )}
        </div>

        {/* Totals */}
        <div className="mt-3 border-t border-slate-700/60 pt-3 space-y-1 text-sm">
          <Row label="Subtotal" value={order?.subtotal} />
          <Row label="Tax" value={order?.tax_total} />
          <Row label="Discount" value={order?.discount_total} />
          <Row label="Delivery Fee" value={order?.delivery_fee} />
          <Row label="Total" value={order?.grand_total} bold />
          <div className="flex gap-2 mt-2">
            <button className="btn w-full">Hold</button>
            <button className="btn btn-primary w-full">Checkout</button>
          </div>
        </div>

        {/* Prepared Orders */}
        <div className="mt-4 border-t border-slate-700/60 pt-3 overflow-auto">
          <div className="flex items-center justify-between mb-2">
            <div className="font-semibold">Prepared Orders</div>
            <button className="btn btn-ghost text-xs" onClick={actions.refreshPrepared}>Refresh</button>
          </div>
          <Table aria-label="Prepared Orders">
            <TableHeader>
              <TableColumn>Order</TableColumn>
              <TableColumn>Status</TableColumn>
              <TableColumn>Total</TableColumn>
            </TableHeader>
            <TableBody items={prepared}>
              {(item) => (
                <TableRow key={item.id}>
                  <TableCell>#{item.number}</TableCell>
                  <TableCell>{item.status}</TableCell>
                  <TableCell>{Number(item.grand_total ?? 0).toFixed(3)}</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
            {prepared.length === 0 && <div className="muted text-sm p-4">No prepared orders yet.</div>}
        </div>
      </aside>
    </div>
  );
}

/* --- Small UI helpers --- */

function Tabs(props: { tabs: any[]; currentId: string|null; onSelect: (id: string)=>void; onNew: ()=>void }) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto">
      {props.tabs.map(t => (
        <button
          key={t.id}
          className={`btn ${props.currentId === t.id ? 'bg-slate-800/70' : 'btn-ghost'}`}
          onClick={() => props.onSelect(t.id)}
          title={`Updated ${timeAgo(t.updated_at)}`}
        >
          <span className="mr-2 chip">{labelForType(t.order_type as any)}</span>
          <span>#{t.number}</span>
        </button>
      ))}
      <button className="btn btn-primary" onClick={props.onNew}>New Order</button>
    </div>
  );
}

function OrderTypePicker({ value, onChange }: { value: 1|2|3; onChange: (t:1|2|3)=>void }) {
  const opts: { k:1|2|3; label:string }[] = [
    { k:1, label:'Delivery' },
    { k:2, label:'Pickup' },
    { k:3, label:'Dine-in' },
  ];
  return (
    <div className="inline-flex rounded-2xl border border-slate-700/60 overflow-hidden">
      {opts.map(o => (
        <button
          key={o.k}
          className={`px-4 py-2 text-sm ${o.k===value ? 'bg-slate-800/70 font-semibold' : 'hover:bg-slate-800/40'}`}
          onClick={() => onChange(o.k)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value?: number|null; bold?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <div className="muted">{label}</div>
      <div className={bold ? 'font-semibold' : ''}>{Number(value ?? 0).toFixed(3)}</div>
    </div>
  );
}

function labelForType(t: 1|2|3) {
  switch (t) { case 1: return 'Delivery'; case 2: return 'Pickup'; case 3: return 'Dine-in'; default: return 'Order'; }
}

function timeAgo(ts?: number) {
  if (!ts) return 'â€”';
  const d = Date.now() - Number(ts);
  if (d < 60_000) return 'just now';
  const m = Math.floor(d/60_000); if (m < 60) return `${m}m`;
  const h = Math.floor(m/60); if (h < 24) return `${h}h`;
  const days = Math.floor(h/24); return `${days}d`;
}