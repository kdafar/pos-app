import React from 'react';

export function AddonsPage() {
  return <div>Addons Page</div>;
}
