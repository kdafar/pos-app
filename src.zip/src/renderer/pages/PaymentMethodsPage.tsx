import { useMemo, useState, useEffect } from 'react';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getFilteredRowModel,
  getSortedRowModel,
} from '@tanstack/react-table';

type PaymentMethod = {
  slug: string;
  name_en: string;
  name_ar: string;
  legacy_code: string;
  is_active: boolean;
  sort_order: number;
};

const columnHelper = createColumnHelper<PaymentMethod>();

const columns = [
  columnHelper.accessor('sort_order', { header: 'Sort' }),
  columnHelper.accessor('slug', { header: 'Slug' }),
  columnHelper.accessor('name_en', { header: 'Name (EN)' }),
  columnHelper.accessor('name_ar', { header: 'Name (AR)' }),
  columnHelper.accessor('legacy_code', { header: 'Legacy Code' }),
  columnHelper.accessor('is_active', { header: 'Active', cell: info => (info.getValue() ? '✅' : '—') }),
];

function GlobalFilter({ filter, setFilter }) {
  return (
    <input
      value={filter || ''}
      onChange={e => setFilter(e.target.value)}
      placeholder={`Search...`}
      className="p-2 border rounded"
    />
  );
}

function PaymentMethodsPage() {
  const [data, setData] = useState<PaymentMethod[]>([]);
  const [globalFilter, setGlobalFilter] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      const methods = await window.api.invoke('payments:listMethods');
      setData(methods);
    };
    fetchData();
  }, []);

  const table = useReactTable({
    data,
    columns,
    state: {
      globalFilter,
    },
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Payment Methods</h1>
        <GlobalFilter
          filter={globalFilter}
          setFilter={setGlobalFilter}
        />
      </div>
      <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            {table.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th key={header.id} onClick={header.column.getToggleSortingHandler()} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer">
                    {flexRender(header.column.columnDef.header, header.getContext())}
                    {{
                      asc: ' 🔼',
                      desc: ' 🔽',
                    }[header.column.getIsSorted() as string] ?? null}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {table.getRowModel().rows.map(row => (
              <tr key={row.id}>
                {row.getVisibleCells().map(cell => (
                  <td key={cell.id} className="px-6 py-4 whitespace-nowrap">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default PaymentMethodsPage;