import { useMemo, useState, useEffect } from 'react';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getFilteredRowModel,
  getSortedRowModel,
} from '@tanstack/react-table';

type State = {
  name: string;
  name_ar: string;
  is_active: boolean;
};

type City = {
  name: string;
  name_ar: string;
  state_id: string;
  min_order: number;
  delivery_fee: number;
  is_active: boolean;
};

const stateColumnHelper = createColumnHelper<State>();
const cityColumnHelper = createColumnHelper<City>();

const stateColumns = [
  stateColumnHelper.accessor('name', { header: 'Name' }),
  stateColumnHelper.accessor('name_ar', { header: 'Name (AR)' }),
  stateColumnHelper.accessor('is_active', { header: 'Active', cell: info => (info.getValue() ? '✅' : '—') }),
];

const cityColumns = [
  cityColumnHelper.accessor('name', { header: 'Name' }),
  cityColumnHelper.accessor('name_ar', { header: 'Name (AR)' }),
  cityColumnHelper.accessor('state_id', { header: 'State ID' }),
  cityColumnHelper.accessor('min_order', { header: 'Min Order' }),
  cityColumnHelper.accessor('delivery_fee', { header: 'Delivery Fee' }),
  cityColumnHelper.accessor('is_active', { header: 'Active', cell: info => (info.getValue() ? '✅' : '—') }),
];

function LocationsPage() {
  const [states, setStates] = useState<State[]>([]);
  const [cities, setCities] = useState<City[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const [statesData, citiesData] = await Promise.all([
        window.api.invoke('geo:listStates'),
        window.api.invoke('geo:listCities'),
      ]);
      setStates(statesData);
      setCities(citiesData);
    };
    fetchData();
  }, []);

  const statesTable = useReactTable({
    data: states,
    columns: stateColumns,
    getCoreRowModel: getCoreRowModel(),
  });

  const citiesTable = useReactTable({
    data: cities,
    columns: cityColumns,
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Locations</h1>

      <h2 className="text-xl font-bold mt-8 mb-4">States</h2>
      <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            {statesTable.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th key={header.id} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {statesTable.getRowModel().rows.map(row => (
              <tr key={row.id}>
                {row.getVisibleCells().map(cell => (
                  <td key={cell.id} className="px-6 py-4 whitespace-nowrap">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2 className="text-xl font-bold mt-8 mb-4">Cities</h2>
      <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            {citiesTable.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th key={header.id} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {citiesTable.getRowModel().rows.map(row => (
              <tr key={row.id}>
                {row.getVisibleCells().map(cell => (
                  <td key={cell.id} className="px-6 py-4 whitespace-nowrap">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default LocationsPage;