import React, { useEffect } from 'react';
import { useStore } from '../src/store';
import {Table, TableHeader, TableColumn, TableBody, TableRow, TableCell, Input, Button} from "@heroui/react";

export function ItemsPage() {
  const { items, q, actions } = useStore();

  useEffect(() => {
    actions.refreshItems();
  }, []);

  return (
    <div style={{ margin: '24px' }}>
      <div className="toolbar" style={{ marginBottom: '20px' }}>
        <h3>Items</h3>
        <div style={{ display: 'flex', gap: '12px' }}>
          <Input
            aria-label="Search"
            placeholder="Search items..."
            value={q}
            onChange={(e) => actions.setQ(e.target.value)}
            onKeyDown={(e) => (e.key === 'Enter') && actions.refreshItems()}
            style={{ minWidth: '300px' }}
          />
          <Button onClick={() => actions.refreshItems()}>Search</Button>
        </div>
      </div>
      <Table aria-label="Items">
        <TableHeader>
          <TableColumn>Name</TableColumn>
          <TableColumn>Arabic Name</TableColumn>
          <TableColumn>Barcode</TableColumn>
          <TableColumn>Price</TableColumn>
          <TableColumn>Stock</TableColumn>
        </TableHeader>
        <TableBody items={items}>
          {(item) => (
            <TableRow key={item.id}>
              <TableCell>{item.name}</TableCell>
              <TableCell>{item.name_ar}</TableCell>
              <TableCell>{item.barcode}</TableCell>
              <TableCell>{item.price.toFixed(3)}</TableCell>
              <TableCell>{item.is_outofstock ? 'Out of Stock' : 'In Stock'}</TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}